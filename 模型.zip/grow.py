"""
最小"关系网络生长"玩具模型
- 时间 = 节点诞生的先后次序（顺向生长，只增不删）
- 起点 = 单个未分化节点（母场的最小替身）
- 每步：新生一个节点，与已有节点建立 m 条关系
- 不同的"选边规则"= 不同的候选动力学，比较它们长出的几何
"""
import numpy as np
import scipy.sparse as sp
from collections import deque
import random

def grow(rule, N, m=2, seed=0, **kw):
    rnd = random.Random(seed)
    adj = [set() for _ in range(N)]
    adj[0].add(1); adj[1].add(0)           # 起点：两个互相关联的节点
    for v in range(2, N):
        targets = rule(adj, v, m, rnd, **kw)
        for u in targets:
            adj[v].add(u); adj[u].add(v)
    return adj

# ---- 规则 ----
def rule_random(adj, v, m, rnd):
    """R0 无局域性：随机连 m 个已有节点（基线）"""
    return rnd.sample(range(v), min(m, v))

def rule_closure(adj, v, m, rnd):
    """R1 三角闭合：连一个种子，再连种子的邻居（局域性偏好）"""
    s = rnd.randrange(v)
    t = {s}
    nb = list(adj[s])
    rnd.shuffle(nb)
    for u in nb:
        if len(t) >= m: break
        t.add(u)
    return t

def rule_frontier(adj, v, m, rnd, window=60):
    """R2 前沿生长：种子只从最近诞生的 window 个节点里选
       （新关系只在"当下前沿"附近建立，类似因果集的序贯生长）"""
    lo = max(0, v - window)
    s = rnd.randrange(lo, v)
    t = {s}
    nb = list(adj[s]); rnd.shuffle(nb)
    for u in nb:
        if len(t) >= m: break
        t.add(u)
    return t

def rule_capped(adj, v, m, rnd, kmax=6):
    """R3 容量饱和：每个节点最多 kmax 条关系；只有未饱和节点能接收新关系
       -> 内部冻结，只在"前沿"生长"""
    for _ in range(200):
        s = rnd.randrange(v)
        if len(adj[s]) < kmax: break
    else:
        s = min(range(v), key=lambda i: len(adj[i]))
    t = {s}
    nb = [u for u in adj[s] if len(adj[u]) < kmax]
    rnd.shuffle(nb)
    for u in nb:
        if len(t) >= m: break
        t.add(u)
    return t

# ---- 测量 ----
def bfs_ball_sizes(adj, src, rmax):
    dist = {src: 0}; q = deque([src]); cnt = [0]*(rmax+1)
    while q:
        x = q.popleft(); d = dist[x]
        if d > rmax: continue
        cnt[d] += 1
        if d == rmax: continue
        for y in adj[x]:
            if y not in dist:
                dist[y] = d+1; q.append(y)
    return np.cumsum(cnt)

def hausdorff_dim(adj, rmax=12, nsrc=60, seed=1):
    """球体增长 N(r) ~ r^d：取中段做对数斜率；同时返回直径量级"""
    rnd = random.Random(seed); n = len(adj)
    # 只在较"老"的节点中取样，避开边缘效应
    srcs = [rnd.randrange(0, n//2) for _ in range(nsrc)]
    mean = np.mean([bfs_ball_sizes(adj, s, rmax) for s in srcs], axis=0)
    r = np.arange(rmax+1)
    # 取 N(r) 介于 20 与 n/4 之间的区段拟合
    mask = (mean > 20) & (mean < n/4) & (r > 0)
    if mask.sum() < 3:
        return float('nan'), mean
    slope = np.polyfit(np.log(r[mask]), np.log(mean[mask]), 1)[0]
    return slope, mean

def spectral_dim(adj, tmax=200, nsrc=40, seed=2):
    """随机游走返回概率 P(t) ~ t^(-ds/2)"""
    n = len(adj); rnd = random.Random(seed)
    rows, cols = [], []
    for i, a in enumerate(adj):
        for j in a: rows.append(i); cols.append(j)
    A = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n))
    deg = np.asarray(A.sum(1)).ravel()
    # 懒惰游走，避免二分图振荡
    P = 0.5*sp.eye(n) + 0.5*sp.diags(1/deg) @ A
    srcs = [rnd.randrange(0, n//2) for _ in range(nsrc)]
    ret = np.zeros(tmax+1)
    for s in srcs:
        x = np.zeros(n); x[s] = 1
        for t in range(1, tmax+1):
            x = P.T @ x
            ret[t] += x[s]
    ret /= nsrc
    t = np.arange(1, tmax+1)
    lo, hi = 10, tmax
    ds = -2*np.polyfit(np.log(t[lo:hi]), np.log(ret[1:][lo:hi]), 1)[0]
    return ds, ret

def degree_entropy(adj):
    """粗粒化熵：度分布的香农熵（可区分的"局部状态类型"有多丰富）"""
    deg = np.array([len(a) for a in adj])
    vals, c = np.unique(deg, return_counts=True)
    p = c/c.sum()
    return float(-(p*np.log2(p)).sum())

def local_signature_entropy(adj):
    """更细的粗粒化：(度, 邻居度之和 分桶) 作为局部签名"""
    sig = []
    for a in adj:
        d = len(a)
        s = sum(len(adj[u]) for u in a)
        sig.append((d, int(np.log2(s+1))))
    vals, c = np.unique(np.array(sig), axis=0, return_counts=True)
    p = c/c.sum()
    return float(-(p*np.log2(p)).sum())

if __name__ == "__main__":
    import sys
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    rules = {"R0 随机": (rule_random, {}),
             "R1 三角闭合": (rule_closure, {}),
             "R2 前沿生长(w=60)": (rule_frontier, {"window": 60}),
             "R3 容量饱和(kmax=8)": (rule_capped, {"kmax": 8})}
    for name, (rule, kw) in rules.items():
        adj = grow(rule, N, m=2, seed=7, **kw)
        dh, ball = hausdorff_dim(adj)
        ds, _ = spectral_dim(adj)
        print(f"{name:18s} N={N}  d_H≈{dh:5.2f}  d_s≈{ds:5.2f}  "
              f"ball(r=1..8)={np.round(ball[1:9]).astype(int).tolist()}  "
              f"H_deg={degree_entropy(adj):.2f}")

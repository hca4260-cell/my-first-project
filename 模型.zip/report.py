import numpy as np, random
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from grow import *

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "WenQuanYi Zen Hei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

N = 3000
# 1) 熵随生长时间：同一条生长史上，在不同时刻截取"当时的网络"
def entropy_history(rule, steps, **kw):
    adj = grow(rule, N, m=2, seed=11, **kw)
    out = []
    for n in steps:
        sub = [set(u for u in a if u < n) for a in adj[:n]]
        out.append((degree_entropy(sub), local_signature_entropy(sub)))
    return np.array(out)

steps = [2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 3000]
H_cap = entropy_history(rule_capped, steps, kmax=6)
H_rnd = entropy_history(rule_random, steps)

# 2) 维度 vs 参数（多个随机种子取均值，看涨落）
ks = [3, 4, 5, 6, 7, 8, 10]
dim = []
for k in ks:
    vals = []
    for sd in range(4):
        adj = grow(rule_capped, N, m=2, seed=100+sd, kmax=k)
        vals.append(hausdorff_dim(adj)[0])
    dim.append((np.nanmean(vals), np.nanstd(vals)))
dim = np.array(dim)
print("kmax vs d_H:", [(k, round(m,2), round(s,2)) for k,(m,s) in zip(ks, dim)])

fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
ax[0].errorbar(ks, dim[:,0], yerr=dim[:,1], marker="o", capsize=3)
ax[0].axhline(3, ls="--", c="gray"); ax[0].text(ks[0], 3.05, "d=3", color="gray")
ax[0].set_xlabel("每个节点的关系容量上限 kmax"); ax[0].set_ylabel("有效维度 d_H（球体增长）")
ax[0].set_title("维度随参数连续变化，而非自动锁定在 3")
ax[1].plot(steps, H_cap[:,1], "o-", label="R3 容量饱和：局部签名熵")
ax[1].plot(steps, H_rnd[:,1], "s--", label="R0 随机：局部签名熵")
ax[1].set_xscale("log"); ax[1].set_xlabel("生长步数（时间）"); ax[1].set_ylabel("粗粒化熵（bit）")
ax[1].set_title("从未分化出发，可区分状态随生长增多"); ax[1].legend()
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/toy_growth_results.png", dpi=130)
print("entropy (cap, sig):", np.round(H_cap[:,1],2).tolist())
print("entropy (rnd, sig):", np.round(H_rnd[:,1],2).tolist())
